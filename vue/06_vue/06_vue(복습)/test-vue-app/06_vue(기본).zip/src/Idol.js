export default class Idol {
  constructor(id, name, checked) {
    this.id = id;
    this.name = name;
    this.checked = checked;
  }
}
